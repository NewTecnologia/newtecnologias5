// Configurações principais
const PAYMENT_LINKS = {
  fone: "https://pag.ae/7_Z7ScjYL",
  smart: "https://pag.ae/7_Z82amG7",
  kit: "https://pag.ae/7_Z83-WKs",
};

// Elementos
const yearEl = document.getElementById('year');
if (yearEl) yearEl.textContent = new Date().getFullYear();

const modal = document.getElementById('modal');
const modalClose = document.querySelector('.modal-close');
const buyButtons = document.querySelectorAll('.buy-btn');
const form = document.getElementById('checkoutForm');
const produtoInput = document.getElementById('produtoInput');
const nextInput = document.getElementById('nextInput');

// Abrir modal com o produto correto
buyButtons.forEach(btn => {
  btn.addEventListener('click', () => {
    const productName = btn.dataset.product || '';
    const paymentKey = btn.dataset.payment || 'fone';
    const payUrl = PAYMENT_LINKS[paymentKey];
    produtoInput.value = productName;
    nextInput.value = payUrl; // o FormSubmit redireciona para o _next após enviar os dados
    modal.classList.remove('hidden');
  });
});

// Fechar modal
if (modalClose) modalClose.addEventListener('click', () => modal.classList.add('hidden'));
modal?.addEventListener('click', (e) => {
  if (e.target === modal) modal.classList.add('hidden');
});

// Persistir lead no LocalStorage antes do envio
form?.addEventListener('submit', (e) => {
  try {
    const data = new FormData(form);
    const lead = {
      timestamp: new Date().toLocaleString('pt-BR'),
      produto: data.get('produto') || '',
      nome: data.get('nome') || '',
      telefone: data.get('telefone') || '',
      email: data.get('email') || '',
      cpf: data.get('cpf') || '',
      cep: data.get('cep') || '',
      endereco: data.get('endereco') || '',
      cidade: data.get('cidade') || '',
      estado: data.get('estado') || '',
    };
    const current = JSON.parse(localStorage.getItem('nt_leads') || '[]');
    current.push(lead);
    localStorage.setItem('nt_leads', JSON.stringify(current));
  } catch(err){ /* silencioso */ }
});
