
# NewTecnologias — Pacote pronto para deploy (Vercel / GitHub Pages)
Gerado em 2025-08-24 16:23:38

## Como publicar na Vercel (recomendado)
1. Suba **todos os arquivos** deste pacote na raiz do seu repositório GitHub.
2. Na Vercel, **Import Project** do GitHub.
3. Project Settings:
   - Framework Preset: **Other**
   - Build Command: **(vazio)**
   - Output Directory: **(vazio)**
4. Deploy.

> O `vercel.json` já está configurado para evitar 404 (todas as rotas caem no `index.html`).

## Como publicar no GitHub Pages
1. Suba todos os arquivos na **branch `main`**.
2. Settings > Pages > Source: **main / (root)**.

## Links de pagamento (PagBank) usados
- Fone Max: https://pag.ae/7_Z7ScjYL
- Smartwatch Ultra: https://pag.ae/7_Z82amG7
- Kit Duo: https://pag.ae/7_Z83-WKs

Se precisar alterar, edite no arquivo `script.js` (const `PAYMENT_LINKS`).

## E-mail para coleta de leads (FormSubmit)
- Os dados são enviados para **newtecnologias00@gmail.com** via FormSubmit.
- Também ficam salvos **localmente no navegador** (LocalStorage).
- Você pode exportar em CSV pela página `/leads.html`.

## Observações
- Layout **escuro**, sem menção a marcas de terceiros.
- Botões com cores de neurociência: **vermelho** (Fone Max), **laranja** (Smartwatch Ultra), **verde** (Kit Duo).
- Ícone do WhatsApp flutuante: **+55 44 99709-7201**.
- Frete grátis destacado como gatilho de conversão.
